const test = () => {
  console.log(23432)
  alert(1)
}

test()