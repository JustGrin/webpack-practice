const  echoC = () => {
  console.log('cccccc')
}
echoC()