# package.json

## script

### webpack

```
config         1.指定 webpack配置文件是名字, 默认是'webpack.config.js'
progress       2.显示打包的过程
display-modue  3.看到打包的模块
color          4.打包的字的彩色的
display-reason 5.打包的原因

```