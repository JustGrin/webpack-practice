const  echoA = () => {
  console.log('aaaaaaaaaa')
}
echoA()