const  echoB = () => {
  console.log('bbbbbbbbbb')
}
echoB()