var htmlWebpackPlugin = require('html-webpack-plugin')

const pagsInfo = [
  { filename: 'index.html', title: 'this is index', minify: { removeComments: true, collapseWhitespace: true } },
  { filename: 'a.html', title: 'this is A', excludeChunks: ['b', 'c'] },
  { filename: 'b.html', title: 'this is B', excludeChunks: ['a', 'c'] },
  { filename: 'c.html', title: 'this is C', excludeChunks: ['b', 'a'] },
]

const getHtml = (fileCnf, template = 'index.html') => {
  const defaultCnf = {
    inject: false,
    template,
  }
  return new htmlWebpackPlugin({ ...defaultCnf, ...fileCnf })
}


module.exports = () => {
  const config = {
    entry: {
      main: './src/script/main.js',
      a: './src/script/js/a.js',
      b: './src/script/js/b.js',
      c: './src/script/js/c.js',
    },
    output: {
      path: `${__dirname}/dist`,
      filename: "[name]-[chunkhash].js",
      publicPath: 'http://www.cctv.com/'
    },
    plugins: pagsInfo.map(item => getHtml(item))
  }
  return config
}

